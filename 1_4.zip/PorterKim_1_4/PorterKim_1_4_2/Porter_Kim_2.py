# -*- coding: utf-8 -*-
'''
JDoe_JSmith_1_4_2: Read and show an image.
'''
import matplotlib.pyplot as plt
import os.path
import numpy as np 
   

directory = os.path.dirname(os.path.abspath(__file__)) 
filename = os.path.join(directory, 'cat1-a.gif')
img = plt.imread(filename)
  
fig, ax = plt.subplots(1, 5)
ax[0].set_xlim(35,15)
ax[1].set_xlim(10,40)
ax[2].set_xlim(36,54)
ax[3].set_xlim(18,78)
ax[4].set_xlim(20,15)


for pic in ax:
    pic.set_ylim(70,80)
    pic.imshow(img,interpolation='none')

fig.show()

