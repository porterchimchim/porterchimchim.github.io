import matplotlib.pyplot as plt
import numpy as np
import PIL

def make_mask(rows, columns, stripe_width):
    '''An example mask generator
    Makes slanted stripes of width stripe_width
    image
    returns an ndarray of an RGBA image rows by columns
    '''
    
    img = PIL.Image.new('RGBA', (columns, rows))
    image = np.array(img)
    for row in range(rows):
        for column in range(columns):
            if (row+column)/stripe_width % 2 == 0: 
                #(r+c)/w says how many stripes above/below line y=x
                # The % 2 says whether it is an even or odd stripe
                
                # Even stripe
                image[row][column] = [row, 127, 255, 255] # pale red, alpha=0
            elif (row+column)/stripe_width % 2 == 0: 
                #(r+c)/w says how many stripes above/below line y=x
                # The % 2 says whether it is an even or odd stripe
                
                # Even stripe
                image[row][column] = [20,45, 255, 255] # pale red, alpha=0
            
            if (row+column)/stripe_width % 2 == 0: 
                #(r+c)/w says how many stripes above/below line y=x
                # The % 2 says whether it is an even or odd stripe
                
                # Even stripe
                image[row][column] = [row, 15, 200, 255] # pale red, alpha=0
            
            else:
                # Odd stripe
                image[row][column] = [column, 20, column, 255] # magenta, alpha=255
    return image
    
if __name__ == "__main__":
    image = make_mask(200,255,20)
    
    fig, ax = plt.subplots(1, 1)
    ax.imshow(image)
    fig.show()            
              
