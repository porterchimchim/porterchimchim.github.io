'''
JDoe_JSmith_1_4_3: Change pixels in an image.
'''
import matplotlib.pyplot as plt
import os.path
import numpy as np  # "as" lets us use standard abbreviations
   
'''Read the image data'''
# Get the directory of this python script
directory = os.path.dirname(os.path.abspath(__file__)) 
# Build an absolute filename from directory + filename
filename = os.path.join(directory, 'woman.jpg')
# Read the image data into an array
img = plt.imread(filename)
height = len(img)
width = len(img[0])
for r in range(417, 466):
    for c in range(130,162):
        if sum(img[r][c])>500: # brightness R+G+B goes up to 3*255=765
            img[r][c] = [0, 255, 0] 
'''Show the image data'''
# Create figure with 1 subplot
###
# Change a region if condition is True
###
  

fig, ax = plt.subplots(1, 1)
# Show the image data in a subplot
ax.imshow(img, interpolation='none')

fig.show()
