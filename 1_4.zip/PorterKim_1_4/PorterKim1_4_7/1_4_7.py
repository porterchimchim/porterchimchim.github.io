from PIL import Image, ImageFilter
import os

'''
size_300 = (300,300)
size_700 = (700,700)

for f in os.listdir('.'):
    if f.endswith('.jpg'):
        i = Image.open(f)
        fn, fext = os.path.splitext(f)

        i.thumbnail(size_700)
        i.save('700/{}_700{}'.format(fn,fext))

        i.thumbnail(size_300)
        i.save('300/{}_300{}'.format(fn,fext))
        
'''
image1 = Image.open('suga.jpg')
image1.filter(ImageFilter.GaussianBlur(5)).save('suga_mod.jpg')


from PIL import Image, ImageFilter
import matplotlib.pyplot as plt
import os.path
import numpy as np  # "as" lets us use standard abbreviations
   
'''Read the image data'''
# Get the directory of this python script
directory = os.path.dirname(os.path.abspath(__file__)) 
# Build an absolute filename from directory + filename
#filename = os.path.join(directory, 'chrysler-top-bw1.jpg')
filename = os.path.join(directory, 'suga.jpg')
# Read the image data into an array
img = plt.imread('suga.jpg')
fig, ax = plt.subplots(1, 1)

height = len(img)
width = len(img[0])

print ('width= ',width)
print ('height= ',height)


def changeBG(im):
    
    for row in range(height):
        for col in range(width):
            if (sum(img[row][col]))%5 == 0:
                im[row][col] = [row, col, 125,]  
    '''
    for row in range(height):
        for col in range(width):
            if sum(img[row][col])>500:
                img[row][col] = [100, 100, 255,]  
    '''
changeBG(img)
        
# Show the image data in a subplot
ax.imshow(img, interpolation='none')

# Show the figure on the screen
fig.show()

        

print(type(img))
