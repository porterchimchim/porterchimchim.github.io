#This is the loop using while statements.

def loop():
    acc = int(input('Input a number greater than 5: ')) 
    while acc > 0:
        acc = acc - 1
        print (acc)


loop()
    
