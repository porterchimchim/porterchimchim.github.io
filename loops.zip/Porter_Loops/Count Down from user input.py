import time

print ("Input a number, and I will count down from it until 0.")

ans = int(input())

for i in range (ans,-1,-1):
    time.sleep (1)
    print (i)
