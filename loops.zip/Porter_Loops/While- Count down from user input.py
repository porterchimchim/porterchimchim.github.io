import time

print ("Enter a number and I will count back from it to 0")
ans = int(input())

acc = ans

while acc > -1:
    time.sleep(1)
    print (acc)
    acc = acc - 1
    
