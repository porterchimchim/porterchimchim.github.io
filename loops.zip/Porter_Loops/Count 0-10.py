for i in range(0,11,1):
    print (i)
