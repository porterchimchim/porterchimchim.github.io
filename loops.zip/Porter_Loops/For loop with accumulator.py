def acc():
    print ("Input a positive integer.")
    x = int(input())
    acc=0
    if x > 0:
        for i in range(0,x):
            acc = acc + i
            print (acc)
    else:
        return acc()

acc()
            
