for i in range(10,-1,-1):
    print(i)
